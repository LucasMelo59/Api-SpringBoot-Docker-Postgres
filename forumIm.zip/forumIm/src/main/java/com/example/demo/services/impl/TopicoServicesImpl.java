package com.example.demo.services.impl;

import com.example.demo.Module.Curso;
import com.example.demo.Module.Topico;
import com.example.demo.Module.dto.DetalheTopicoDto;
import com.example.demo.Module.dto.TopicoDto;
import com.example.demo.form.AtualizacaoTopicoForm;
import com.example.demo.form.TopicoForm;
import com.example.demo.repositories.CursoRepository;
import com.example.demo.repositories.TopicoRepository;
import com.example.demo.services.TopicoServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TopicoServicesImpl implements TopicoServices {

   @Autowired
   private CursoRepository cursoRepository;
   @Autowired
   private TopicoRepository topicoRepository;

    public Topico cadastrar(TopicoForm form) {
        Curso curso = cursoRepository.findByNome(form.getNomeCurso());
        //Optional<Curso> restricao = Optional.ofNullable(cursoRepository.findByNome(form.getNomeCurso()));
        //if(restricao.isPresent()) {
            Topico topico = new Topico(form.getTitulo(), form.getMensagem(), curso);
//        URI uri = uriBuilder.path("/topicos/{id}").buildAndExpand(topico.getId()).toUri();
            return topicoRepository.save(topico);
        //} else{
          //  throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "");
        //}
    }

    @Override
    public Optional<DetalheTopicoDto> detalhar(Long id) {
//        return topicoRepository.findById(id).map(topico -> DetalheTopicoDto.converter(topico));
        return topicoRepository.findById(id).map(DetalheTopicoDto::converter);


//        if(topico.isPresent()) {
//            return ResponseEntity.ok(new DetalheTopicoDto(topico.get()));
//        }
//
//        return ResponseEntity.notFound().build();
    }



    @Override
    public Optional<TopicoDto> atualizar(Long id, AtualizacaoTopicoForm form) {
//        return form.atualizar(id,topicoRepository).map(topico -> TopicoDto.converter(topico));
        Topico topico = topicoRepository.getById(id);
        topico.setTitulo(form.getTitulo());
        topico.setMensagem(form.getMensagem());

        return Optional.of(topicoRepository.saveAndFlush(topico)).map(TopicoDto::converter);

//        if(optional.isPresent()) {
//            Topico topico = form.atualizar(id, topicoRepository);
//            return ResponseEntity.ok(new TopicoDto(topico));
//        }
//
//        return ResponseEntity.notFound().build();
    }

    @Override
    public void remover(Long id) {
          Optional<Topico> remover = topicoRepository.findById(id);
        if (remover.isPresent()){
            topicoRepository.deleteById(id);
        } else{
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, " deu certo");
        }

        }


    @Override
    public List<TopicoDto> lista() {
            return topicoRepository.findAll().stream().map(TopicoDto::new).collect(Collectors.toList());
            // utlizar o metodo converter em vez de new

        }
}



