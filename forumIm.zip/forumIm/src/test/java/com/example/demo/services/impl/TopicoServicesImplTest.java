package com.example.demo.services.impl;

import com.example.demo.Module.Curso;
import com.example.demo.Module.Topico;
import com.example.demo.Module.dto.DetalheTopicoDto;
import com.example.demo.Module.dto.TopicoDto;
import com.example.demo.repositories.CursoRepository;
import com.example.demo.repositories.TopicoRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class TopicoServicesImplTest {
    private static final Long ID = 1L;


    @InjectMocks
    private TopicoServicesImpl service;
    @Mock
    private TopicoRepository repository;
    @Mock
    private CursoRepository cursoRepository;

    @Test
    void cadastrar() {
        MockitoAnnotations.openMocks(this);
        startUser();
    }

    @Test
    void detalhar() {

        Optional<DetalheTopicoDto> response;
        response = service.detalhar(ID);
        Assertions.assertTrue(response.isPresent());



    }

    @Test
    void atualizar() {
    }

    @Test
    void remover() {
    }

    @Test
    void lista() {
    }

    @BeforeEach
    private void startUser() {
        String TITULO = "ola";
         String MENSAGEM = "esta funcional";
         Curso CURSO = new Curso("pedro");
        Topico topico = new Topico(TITULO, MENSAGEM, CURSO);
        TopicoDto topicoDto = new TopicoDto(topico);
        Optional<Topico> optionalTopico = Optional.of(topico);
        Mockito.when(repository.findById(Mockito.anyLong())).thenReturn(optionalTopico);
    }


}